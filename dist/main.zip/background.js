chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['contentScript.js']
    });
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: function() {
            return {
                opacity: localStorage.getItem('opacity') || '0.2',
                selectedColor: localStorage.getItem('selectedColor') || '#000000'
            };
        }
    }, (results) => {
        const { opacity, selectedColor } = results[0].result;
        // Use the retrieved data here
        chrome.storage.local.set({ [tab.id]: { opacity, color: selectedColor } });
    });
});
