function createOverlay(opacity, color) {
    const alreadyDimmer = document.getElementById('dimmerOverlay');
    if (alreadyDimmer) {
        alreadyDimmer.style.opacity = opacity;
        alreadyDimmer.style.backgroundColor = color;
    } else {
        // Create the overlay
        const overlay = document.createElement('div');
        overlay.id = 'dimmerOverlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = color;
        overlay.style.opacity = opacity;
        overlay.style.pointerEvents = 'none';
        overlay.style.zIndex = '9999999999999999999999';

        // Add the overlay to the body
        document.body.appendChild(overlay);
    }
}

function memoryDimmer(opacity, color) {
    chrome.storage.local.get([window.location.href], (result) => {
        const currentTabData = result[window.location.href] || {};
        currentTabData.opacity = opacity;
        currentTabData.color = color;
        chrome.storage.local.set({ [window.location.href]: currentTabData });
    });
}

document.addEventListener('DOMContentLoaded', function () {
    const slider = document.getElementById('opacitySlider');
    const opacityValue = document.getElementById('opacityValue');
    const colorInput = document.getElementById("favcolor");
    const favColorOverlay = document.getElementById("favColorOverlay");
    const bearOverlay = document.getElementById("bearOverlay");

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const activeTab = tabs[0];
        if (activeTab.url.startsWith('chrome://')) {
            return; // Prevent script execution on chrome:// pages
        }
        chrome.storage.local.get([activeTab.url], (result) => {
            const { opacity, color } = result[activeTab.url] || {};
            if (opacity !== undefined) {
                slider.value = opacity * 100;
                opacityValue.textContent = opacity * 100 + '%';
            }
            if (color !== undefined) {
                colorInput.value = color;
                colorInput.style.backgroundColor = colorInput.value
            }
        });

        slider.addEventListener('input', function () {
            const selectedColor = colorInput.value;
            colorInput.style.backgroundColor = colorInput.value
            favColorOverlay.style.backgroundColor = colorInput.value
            const opacity = slider.value / 100;
            bearOverlay.style.opacity = opacity;
            opacityValue.textContent = slider.value + '%';

            // Save the selected opacity to local storage
            chrome.storage.local.get([activeTab.url], (result) => {
                const currentTabData = result[activeTab.url] || {};
                currentTabData.opacity = opacity;
                currentTabData.color = selectedColor;
                chrome.storage.local.set({ [activeTab.url]: currentTabData });
            });

            // Inject script to change overlay opacity in the active tab
            chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: createOverlay,
                args: [opacity, selectedColor]
            });
        });

        colorInput.addEventListener("input", function () {
            const selectedColor = colorInput.value;
            colorInput.style.backgroundColor = colorInput.value
            favColorOverlay.style.backgroundColor = colorInput.value
            const opacity = slider.value / 100;
            bearOverlay.style.opacity = opacity;

            // Save the selected color to local storage
            chrome.storage.local.get([activeTab.url], (result) => {
                const currentTabData = result[activeTab.url] || {};
                currentTabData.opacity = opacity;
                currentTabData.color = selectedColor;
                chrome.storage.local.set({ [activeTab.url]: currentTabData });
            });

            // Inject script to change overlay opacity in the active tab
            chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: createOverlay,
                args: [opacity, selectedColor]
            });
        });

        document.querySelectorAll('.filter-circle').forEach(circle => {
            circle.addEventListener('click', function () {
                const opacityyy = this.getAttribute('data-opacity');
                const color = this.getAttribute('data-color');
                slider.value = opacityyy;
                colorInput.value = color;

                colorInput.style.backgroundColor = colorInput.value
                favColorOverlay.style.backgroundColor = colorInput.value
                bearOverlay.style.opacity = opacityyy / 100;

                opacityValue.textContent = opacityyy + '%';

                chrome.storage.local.get([activeTab.url], (result) => {
                    const currentTabData = result[activeTab.url] || {};
                    currentTabData.opacity = opacityyy / 100;
                    currentTabData.color = color;
                    chrome.storage.local.set({ [activeTab.url]: currentTabData });
                });

                // Inject script to change overlay opacity in the active tab
                chrome.scripting.executeScript({
                    target: { tabId: activeTab.id },
                    func: createOverlay,
                    args: [opacityyy / 100, color]
                });
            });
        });
    });
});
