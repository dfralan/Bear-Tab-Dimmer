function firstOverlay(opacity, color) {
    const alreadyDimmer = document.getElementById('dimmerOverlay');
    if (alreadyDimmer) {
        alreadyDimmer.style.opacity = opacity;
        alreadyDimmer.style.backgroundColor = color;
    } else {
        // Create the overlay
        const overlay = document.createElement('div');
        overlay.id = 'dimmerOverlay';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = color;
        overlay.style.opacity = opacity;
        overlay.style.pointerEvents = 'none';
        overlay.style.zIndex = '9999999999999999999999';

        // Add the overlay to the body
        document.body.appendChild(overlay);
    }
}

chrome.storage.local.get([document.location.href], (result) => {
    const { opacity, color } = result[document.location.href] || {};
    const validOpacity = (opacity >= 0 && opacity <= 1) ? opacity : 0.2; // default to 0.2 if invalid
    const validColor = color || '#000000'; // default to black if not found
    firstOverlay(validOpacity, validColor);
});
